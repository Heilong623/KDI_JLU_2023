from py2neo import Graph

GRAPH_DB_CONN = Graph("http://127.0.0.1:7474",auth=("neo4j","ztxgj999"), name="neo4j")