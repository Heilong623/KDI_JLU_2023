

from question_classifier import *
from question_parser import *
from answer_search import *

'''问答类'''
class ChatBotGraph():
    def __init__(self, pDate):
        self.classifier = QuestionClassifier()
        self.parser = QuestionPaser(pDate)
        self.searcher = AnswerSearcher()

    def chat_kg_main(self, sent):
        answer = '嘤嘤嘤，你还真问倒我了呢！'
        res_classify = self.classifier.classify(sent)

        #print(res_classify)

        if not res_classify:
            return '超出我的知识范围了'

        if res_classify['question_types'] == ['sensitive']:
            return '输入中带有敏感词汇'

        res_sql = self.parser.parser_main(res_classify)
        final_answers = self.searcher.search_main(res_sql)
        if not final_answers:
            return answer
        else:
            return '\n'.join(final_answers)

if __name__ == '__main__':
    #选择当天时间
    pDate = "20230921"
    count=0
    handler = ChatBotGraph(pDate)
    print('Chat: what questions would you like to ask')
    while 1:
        if count==1:
            print("\n")
            count=1
        question = input('User:')
        USE_KG = True
        if USE_KG:
            answer = handler.chat_kg_main(question)
        else:
            answer = handler.chat_interface_main(question)
        print(answer)

