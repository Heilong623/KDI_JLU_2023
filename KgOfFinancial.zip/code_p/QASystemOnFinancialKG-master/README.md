# QABasedOnKnowledgeGraph
# 使用py2graph创建节点和关系 再进行知识融合提高知识图谱的质量 进行知识图谱的建立
 金融领域知识图谱规模
| 实体类型 | 中文含义 | 实体数量 |举例 |
| :--- | :---: | :---: | :--- |
| Stock#PDATE# | 每一天的股票 | 3,359 | 平安银行;同花顺 |
| Concept | 概念 | 1121 | 迪士尼;芯片概念 |
| ConceptLeading | 概念龙头 | 205 | 迪士尼;芯片概念 |
| Controller | 实际控制人 | 2,433 | 王妙玉;李德敏 |
| Industry | 行业 | 66 | 通信服务;纺织制造 |
| IndexType | 指数类型 | 75 | 创业板50;公共指数 |
| EquityScale | 股本规模 | 4 | 小盘股;大盘股|
| MarketType | 市场类型 | 34 | 全部AB股;上证50 |
| BuySignal | 买入信号 | 36 | bias买入信号;boll突破下轨 |
| SellSignal | 卖出信号 | 24 | boll跌破上轨;kdj超买 |
| TechForm | 技术形态 | 69 | 一阳二线;横盘|
| Movement | 选股动向 | 75 | 破净;持续5天放量|

 # 知识图谱实体关系类型
| 实体关系类型 | 中文含义 | 关系数量 | 举例|
| :--- | :---: | :---: | :--- |
| ConceptInvolved | 所属概念 | 8,844| <平安银行,属于,转融券标的>|
| ConceptLeadingInvolved | 概念龙头 | 14,649 | <赛意信息,属于,华为概念>|
| IndustryInvolved |所属行业 | 22,238| |
| IndexTypeIs |  所属指数类 | 17,315| |
| EquityScaleIs | 股本规模 | 39,422| |
| MarketTypeIs | 股票市场类型 | 22,247| |
| TechFormIs | 技术形态 | 59,467 | |
| MovementIs | 选股动向 | 40,221 | |
| BuySignalIs | 买入信号 | 5,998 |  |
| SellSignalIs | 卖出信号 | 12,029 | |
| IsControlledBy | 实际控制人 | 294,149 | |
| TopManagerIs | 高管 | | |
| MainBusinessIs | 主营产品 | | |
| ProvinceIs | 省份 | | |
| CityIs | 城市 | | |
| SchoolIs | 毕业学校 | | |
| EducationBgIs | 学历 | | |
| NationalityIs | 国籍 | | |
| GenderIs | 性别 | | |
| TitleIs | 高管职务 | | |
| Total | 总计 | | |
知识图谱属性类型

| 属性类型 | 中文含义 | 举例 |
| :--- | :---: | :---: |
| stock_id | 股票6位代码 | 000001 |
| stock_code | 股票完整代码 | 000001.SZ |
| stock_name | 股票名称 | 平安银行 |
| industry_ths | 同花顺行业 | 交运设备-交运设备服务-汽车服务 |
| open | 开盘价 | 9.39 |
| close | 收盘价 | 9.39 |
| high | 最高价 | 9.5 |
| low | 最低价 | 9.37 |
| volume_rate | 量比 | 0.86 |


  # 二、基于金融知识图谱的自动问答
 脚本结构
question_classifier.py：问句类型分类脚本
question_parser.py：问句解析脚本
chatbot_graph.py：问答程序脚本

# 支持问答类型

| 问句类型 | 中文含义 | 问句举例 |
| conceptleading_stockget | 行业龙头 | 电子竞技龙头？ | 属于电子竞技概念的龙头股票有：300052 中青宝；600652 游久游戏；300494 盛天网络
| stockname_industryget | 什么行业 | 德宏股份什么行业？ |603701 德宏股份的所属行业是：汽车零部件
| | stockname_topmanagerget | 高管 | 平安银行高管？ | | 平安银行 的高管是：都江源；郭世邦；吕旭光；吴鹏；杨志群；张祐成；姚贵平；周立；项有志；周强；胡跃飞
| stockname_buysignalget | 买入信号 | 游久游戏买入信号？ |游久游戏释放的买入信号有：rsi金叉；lwr买入信号；kdj金叉
| stockname_sellsignalget | 卖出信号 | 阳光城卖出信号？ |阳光城释放的卖出信号有：行情收盘价下穿5日；skdj死叉；rsi死叉
| stockname_techformget | 技术形态 | 川投能源技术形态 ？| 600674 川投能源表现出的技术形态是：小阴星；横盘；阴线
| stockid_conceptget | 查询概念| 平安银行有哪些概念？ |000001 平安银行的所属概念是：优先股概念；深股通；融资融券；MSCI概念；转融券标的；证金持股




